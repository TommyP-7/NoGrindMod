--- Filter Title: No Filter
--- Filter Type: (None)
--- Filter Description: This is not a filter, it applies no changes.
return {
    allowOverrides = true,
    rules = {

    }
}
